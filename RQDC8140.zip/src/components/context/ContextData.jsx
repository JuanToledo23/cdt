import React from 'react';
    let DatosGlobales = React.createContext({
        tieneCredito: true
    });
export default DatosGlobales;